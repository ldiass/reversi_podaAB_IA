#!/bin/bash
python randomplayer.py $1 $2
