#!/bin/bash
cd Trabalho_2_poda_alpha_beta/reversIA 
python reversIA.py $1 $2
#$1 = path to state file
#$2 = 'black' | 'white'


